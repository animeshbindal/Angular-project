export class Movie
{
movieName : String;
giveRating:Int16Array;
genre:String;

}