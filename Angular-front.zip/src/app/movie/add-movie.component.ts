import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { Movie } from 'C:\Users\HP-PC\Assignment-Angular\src\app\model\movie.model';
import { UserService } from 'C:\Users\HP-PC\Assignment-Angular\src\app\movie\movie.service';

@Component({
    templateUrl: './add-movie.component.html'
  })

  export class AddMovieComponent
  {
      movie : Movie = new Movie();
     
     
      constructor(private router: Router, private userService: UserService) {

    }

    AddMovie(): void {
        this.userService.createUser(this.movie)
            .subscribe( data => {
              alert("Movie added successfully.");
            });
    
      };
  }