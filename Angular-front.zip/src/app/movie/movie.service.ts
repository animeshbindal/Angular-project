import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import{Movie} from 'C:\Users\HP-PC\Assignment-Angular\src\app\models\movie.model';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  @Injectable()
export class UserService {

  constructor(private http:HttpClient) {}
  private userUrl = 'http://localhost:8080/Assignment-Angular/movies';
  
  public getUsers() {
    return this.http.get<Movie[]>(this.userUrl);
  }

  public createUser(user) {
    return this.http.post<Movie>(this.userUrl, user);
  }
}